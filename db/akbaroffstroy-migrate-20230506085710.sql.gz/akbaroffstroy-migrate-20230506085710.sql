# Миграция MySQL базы данных WordPress
#
# Сформирован: Saturday 6. May 2023 08:57 UTC
# Адрес сайта: localhost
# База данных: `akbaroff`
# URL: //akbaroff
# Path: C:\\OpenServer\\domains\\akbaroff
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, page, post, postp
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Удалить любую существующую таблицу `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Структура таблицы `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_commentmeta`
#

#
# Конец содержимого данных таблицы `wp_commentmeta`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Структура таблицы `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_comments`
#

#
# Конец содержимого данных таблицы `wp_comments`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Структура таблицы `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_links`
#

#
# Конец содержимого данных таблицы `wp_links`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Структура таблицы `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=362 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://akbaroff', 'yes'),
(2, 'home', 'http://akbaroff', 'yes'),
(3, 'blogname', 'akbaroffStroy', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'xibroxim11@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'd.m.Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'd.m.Y H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:93:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:2:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '3', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'akbaroff', 'yes'),
(41, 'stylesheet', 'akbaroff', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'posts', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '0', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '57', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1696141524', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '53496', 'yes'),
(100, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'fresh_site', '0', 'yes'),
(102, 'WPLANG', 'ru_RU', 'yes'),
(103, 'user_count', '1', 'no'),
(104, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:167:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Свежие записи</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:247:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Свежие комментарии</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Архивы</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Рубрики</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'yes'),
(106, 'cron', 'a:8:{i:1683365130;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1683397530;a:4:{s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1683397609;a:1:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1683440729;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1683440809;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1683440811;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1683699929;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(120, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(124, 'theme_mods_twentytwentythree', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1680621960;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(127, 'recovery_keys', 'a:0:{}', 'yes'),
(128, 'https_detection_errors', 'a:1:{s:23:"ssl_verification_failed";a:1:{i:0;s:38:"Проверка SSL неудачна.";}}', 'yes'),
(144, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:20:"xibroxim11@gmail.com";s:7:"version";s:3:"6.2";s:9:"timestamp";i:1680589607;}', 'no'),
(157, 'can_compress_scripts', '1', 'no'),
(165, 'finished_updating_comment_type', '1', 'yes'),
(175, 'current_theme', 'akbaroff', 'yes'),
(176, 'theme_mods_twentytwentyone', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1680621966;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}}}}', 'yes'),
(177, 'theme_switched', '', 'yes'),
(179, 'theme_mods_akbaroff', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(182, 'category_children', 'a:0:{}', 'yes'),
(187, 'recently_activated', 'a:0:{}', 'yes'),
(188, 'acf_version', '6.1.1', 'yes'),
(205, 'wp_calendar_block_has_published_posts', '1', 'yes'),
(271, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1683363429;}', 'no') ;

#
# Конец содержимого данных таблицы `wp_options`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Структура таблицы `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=189 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(10, 8, '_edit_lock', '1680624146:1'),
(11, 8, '_wp_page_template', 'index.php'),
(15, 11, '_edit_lock', '1680624264:1'),
(16, 11, '_wp_page_template', 'portfolio.php'),
(19, 15, '_edit_lock', '1680632062:1'),
(25, 20, '_edit_last', '1'),
(26, 20, '_edit_lock', '1680644142:1'),
(28, 25, '_edit_lock', '1680625802:1'),
(29, 26, '_wp_attached_file', '2023/04/klassik1.jpg'),
(30, 26, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1036;s:6:"height";i:596;s:4:"file";s:20:"2023/04/klassik1.jpg";s:8:"filesize";i:177391;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:20:"klassik1-300x173.jpg";s:5:"width";i:300;s:6:"height";i:173;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:25901;}s:5:"large";a:5:{s:4:"file";s:21:"klassik1-1024x589.jpg";s:5:"width";i:1024;s:6:"height";i:589;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:143294;}s:9:"thumbnail";a:5:{s:4:"file";s:20:"klassik1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:17492;}s:12:"medium_large";a:5:{s:4:"file";s:20:"klassik1-768x442.jpg";s:5:"width";i:768;s:6:"height";i:442;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:91924;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(31, 25, '_edit_last', '1'),
(32, 25, 'firstimg', '26'),
(33, 25, '_firstimg', 'field_642c4f5aced3e'),
(34, 25, 'title', 'testTitle'),
(35, 25, '_title', 'field_642c4f91ced3f'),
(36, 25, 'subtitle', 'TestSubtitle'),
(37, 25, '_subtitle', 'field_642c4fd6ced40'),
(38, 27, '_edit_lock', '1680627362:1'),
(39, 27, '_edit_last', '1'),
(40, 27, 'firstimg', '26'),
(41, 27, '_firstimg', 'field_642c4f5aced3e'),
(42, 27, 'title', 'test'),
(43, 27, '_title', 'field_642c4f91ced3f'),
(44, 27, 'subtitle', 'safdfasdf'),
(45, 27, '_subtitle', 'field_642c4fd6ced40'),
(58, 30, '_edit_lock', '1680644397:1'),
(61, 30, '_edit_last', '1'),
(62, 30, 'firstimg', '26'),
(63, 30, '_firstimg', 'field_642c4f5aced3e'),
(64, 30, 'title', 'RiverGarden1'),
(65, 30, '_title', 'field_642c4f91ced3f'),
(66, 30, 'subtitle', 'Interyer design1'),
(67, 30, '_subtitle', 'field_642c4fd6ced40'),
(68, 32, 'firstimg', '26'),
(69, 32, '_firstimg', 'field_642c4f5aced3e'),
(70, 32, 'title', 'ewrwerwerwe'),
(71, 32, '_title', 'field_642c4f91ced3f'),
(72, 32, 'subtitle', 'sdfsdfadf'),
(73, 32, '_subtitle', 'field_642c4fd6ced40'),
(76, 30, '_wp_page_template', 'article.php'),
(81, 33, '_edit_lock', '1680644697:1'),
(84, 33, '_wp_page_template', 'article.php'),
(85, 33, '_edit_last', '1'),
(86, 33, 'firstimg', '26'),
(87, 33, '_firstimg', 'field_642c4f5aced3e'),
(88, 33, 'title', 'RiverGarden2'),
(89, 33, '_title', 'field_642c4f91ced3f'),
(90, 33, 'subtitle', 'RiverGarden2'),
(91, 33, '_subtitle', 'field_642c4fd6ced40'),
(92, 35, 'firstimg', '26'),
(93, 35, '_firstimg', 'field_642c4f5aced3e'),
(94, 35, 'title', 'sdgfsvfsr'),
(95, 35, '_title', 'field_642c4f91ced3f'),
(96, 35, 'subtitle', 'dsgagsga'),
(97, 35, '_subtitle', 'field_642c4fd6ced40'),
(100, 41, '_edit_lock', '1680638633:1'),
(101, 42, '_wp_attached_file', '2023/04/loft1.jpg'),
(102, 42, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1000;s:6:"height";i:666;s:4:"file";s:17:"2023/04/loft1.jpg";s:8:"filesize";i:147179;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:17:"loft1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:17957;}s:9:"thumbnail";a:5:{s:4:"file";s:17:"loft1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8706;}s:12:"medium_large";a:5:{s:4:"file";s:17:"loft1-768x511.jpg";s:5:"width";i:768;s:6:"height";i:511;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:84249;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(103, 43, '_wp_attached_file', '2023/04/minimalizm1.jpg'),
(104, 43, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1920;s:6:"height";i:1200;s:4:"file";s:23:"2023/04/minimalizm1.jpg";s:8:"filesize";i:131887;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:23:"minimalizm1-300x188.jpg";s:5:"width";i:300;s:6:"height";i:188;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9284;}s:5:"large";a:5:{s:4:"file";s:24:"minimalizm1-1024x640.jpg";s:5:"width";i:1024;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:57793;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"minimalizm1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4724;}s:12:"medium_large";a:5:{s:4:"file";s:23:"minimalizm1-768x480.jpg";s:5:"width";i:768;s:6:"height";i:480;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:36712;}s:9:"1536x1536";a:5:{s:4:"file";s:24:"minimalizm1-1536x960.jpg";s:5:"width";i:1536;s:6:"height";i:960;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:113626;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(105, 44, '_wp_attached_file', '2023/04/modern1.jpg'),
(106, 44, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1348;s:6:"height";i:899;s:4:"file";s:19:"2023/04/modern1.jpg";s:8:"filesize";i:138216;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:19:"modern1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:12782;}s:5:"large";a:5:{s:4:"file";s:20:"modern1-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:102309;}s:9:"thumbnail";a:5:{s:4:"file";s:19:"modern1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5338;}s:12:"medium_large";a:5:{s:4:"file";s:19:"modern1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:62563;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(107, 45, '_wp_attached_file', '2023/04/more.jpg'),
(108, 45, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1005;s:6:"height";i:753;s:4:"file";s:16:"2023/04/more.jpg";s:8:"filesize";i:154707;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:16:"more-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:14104;}s:9:"thumbnail";a:5:{s:4:"file";s:16:"more-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5687;}s:12:"medium_large";a:5:{s:4:"file";s:16:"more-768x575.jpg";s:5:"width";i:768;s:6:"height";i:575;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:65866;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(109, 46, '_wp_attached_file', '2023/04/neo1.jpg'),
(110, 46, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1000;s:6:"height";i:550;s:4:"file";s:16:"2023/04/neo1.jpg";s:8:"filesize";i:112421;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:16:"neo1-300x165.jpg";s:5:"width";i:300;s:6:"height";i:165;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:18698;}s:9:"thumbnail";a:5:{s:4:"file";s:16:"neo1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:12412;}s:12:"medium_large";a:5:{s:4:"file";s:16:"neo1-768x422.jpg";s:5:"width";i:768;s:6:"height";i:422;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:68058;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(113, 41, '_edit_last', '1'),
(114, 41, 'firstimg', '26'),
(115, 41, '_firstimg', 'field_642c4f5aced3e'),
(116, 41, 'title', 'test3'),
(117, 41, '_title', 'field_642c4f91ced3f'),
(118, 41, 'subtitle', 'wewefasdfas'),
(119, 41, '_subtitle', 'field_642c4fd6ced40'),
(120, 41, 'galarey', 'a:6:{i:0;s:2:"46";i:1;s:2:"45";i:2;s:2:"43";i:3;s:2:"42";i:4;s:2:"44";i:5;s:2:"26";}'),
(121, 41, '_galarey', 'field_642c762b37427'),
(122, 48, 'firstimg', '26'),
(123, 48, '_firstimg', 'field_642c4f5aced3e'),
(124, 48, 'title', 'test3'),
(125, 48, '_title', 'field_642c4f91ced3f'),
(126, 48, 'subtitle', 'wewefasdfas'),
(127, 48, '_subtitle', 'field_642c4fd6ced40'),
(128, 48, 'galarey', '<img class="alignnone size-medium wp-image-42" src="http://akbaroff/wp-content/uploads/2023/04/loft1-300x200.jpg" alt="" width="300" height="200" /> <img class="alignnone size-medium wp-image-43" src="http://akbaroff/wp-content/uploads/2023/04/minimalizm1-300x188.jpg" alt="" width="300" height="188" /> <img class="alignnone size-medium wp-image-44" src="http://akbaroff/wp-content/uploads/2023/04/modern1-300x200.jpg" alt="" width="300" height="200" /> <img class="alignnone size-medium wp-image-45" src="http://akbaroff/wp-content/uploads/2023/04/more-300x225.jpg" alt="" width="300" height="225" /> <img class="alignnone size-medium wp-image-46" src="http://akbaroff/wp-content/uploads/2023/04/neo1-300x165.jpg" alt="" width="300" height="165" />'),
(129, 48, '_galarey', 'field_642c762b37427'),
(134, 41, '_wp_page_template', 'article.php'),
(135, 50, 'firstimg', '26'),
(136, 50, '_firstimg', 'field_642c4f5aced3e'),
(137, 50, 'title', 'test3'),
(138, 50, '_title', 'field_642c4f91ced3f'),
(139, 50, 'subtitle', 'wewefasdfas'),
(140, 50, '_subtitle', 'field_642c4fd6ced40'),
(141, 50, 'galarey', 'a:6:{i:0;s:2:"46";i:1;s:2:"45";i:2;s:2:"43";i:3;s:2:"42";i:4;s:2:"44";i:5;s:2:"26";}'),
(142, 50, '_galarey', 'field_642c762b37427'),
(149, 30, 'galarey', 'a:6:{i:0;s:2:"46";i:1;s:2:"45";i:2;s:2:"44";i:3;s:2:"43";i:4;s:2:"42";i:5;s:2:"26";}'),
(150, 30, '_galarey', 'field_642c762b37427'),
(151, 52, 'firstimg', '26'),
(152, 52, '_firstimg', 'field_642c4f5aced3e'),
(153, 52, 'title', 'RiverGarden'),
(154, 52, '_title', 'field_642c4f91ced3f'),
(155, 52, 'subtitle', 'Interyer design'),
(156, 52, '_subtitle', 'field_642c4fd6ced40') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(157, 52, 'galarey', 'a:6:{i:0;s:2:"46";i:1;s:2:"45";i:2;s:2:"44";i:3;s:2:"43";i:4;s:2:"42";i:5;s:2:"26";}'),
(158, 52, '_galarey', 'field_642c762b37427'),
(161, 53, 'firstimg', '26'),
(162, 53, '_firstimg', 'field_642c4f5aced3e'),
(163, 53, 'title', 'RiverGarden1'),
(164, 53, '_title', 'field_642c4f91ced3f'),
(165, 53, 'subtitle', 'Interyer design1'),
(166, 53, '_subtitle', 'field_642c4fd6ced40'),
(167, 53, 'galarey', 'a:6:{i:0;s:2:"46";i:1;s:2:"45";i:2;s:2:"44";i:3;s:2:"43";i:4;s:2:"42";i:5;s:2:"26";}'),
(168, 53, '_galarey', 'field_642c762b37427'),
(171, 33, 'galarey', 'a:6:{i:0;s:2:"46";i:1;s:2:"45";i:2;s:2:"44";i:3;s:2:"43";i:4;s:2:"42";i:5;s:2:"26";}'),
(172, 33, '_galarey', 'field_642c762b37427'),
(173, 54, 'firstimg', '26'),
(174, 54, '_firstimg', 'field_642c4f5aced3e'),
(175, 54, 'title', 'RiverGarden2'),
(176, 54, '_title', 'field_642c4f91ced3f'),
(177, 54, 'subtitle', 'RiverGarden2'),
(178, 54, '_subtitle', 'field_642c4fd6ced40'),
(179, 54, 'galarey', 'a:6:{i:0;s:2:"46";i:1;s:2:"45";i:2;s:2:"44";i:3;s:2:"43";i:4;s:2:"42";i:5;s:2:"26";}'),
(180, 54, '_galarey', 'field_642c762b37427'),
(182, 56, '_wp_attached_file', '2023/04/logoO.png'),
(183, 56, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:945;s:6:"height";i:467;s:4:"file";s:17:"2023/04/logoO.png";s:8:"filesize";i:57565;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:17:"logoO-300x148.png";s:5:"width";i:300;s:6:"height";i:148;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:17224;}s:9:"thumbnail";a:5:{s:4:"file";s:17:"logoO-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:11070;}s:12:"medium_large";a:5:{s:4:"file";s:17:"logoO-768x380.png";s:5:"width";i:768;s:6:"height";i:380;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:52900;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(184, 57, '_wp_attached_file', '2023/04/cropped-logoO.png'),
(185, 57, '_wp_attachment_context', 'site-icon'),
(186, 57, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:25:"2023/04/cropped-logoO.png";s:8:"filesize";i:48212;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:25:"cropped-logoO-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:28127;}s:9:"thumbnail";a:5:{s:4:"file";s:25:"cropped-logoO-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:11576;}s:13:"site_icon-270";a:5:{s:4:"file";s:25:"cropped-logoO-270x270.png";s:5:"width";i:270;s:6:"height";i:270;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:24739;}s:13:"site_icon-192";a:5:{s:4:"file";s:25:"cropped-logoO-192x192.png";s:5:"width";i:192;s:6:"height";i:192;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:16043;}s:13:"site_icon-180";a:5:{s:4:"file";s:25:"cropped-logoO-180x180.png";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:14776;}s:12:"site_icon-32";a:5:{s:4:"file";s:23:"cropped-logoO-32x32.png";s:5:"width";i:32;s:6:"height";i:32;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1398;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ;

#
# Конец содержимого данных таблицы `wp_postmeta`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Структура таблицы `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(8, 1, '2023-04-04 19:04:26', '2023-04-04 16:04:26', '', 'index', '', 'publish', 'closed', 'closed', '', 'index', '', '', '2023-04-04 19:04:26', '2023-04-04 16:04:26', '', 0, 'http://akbaroff/?page_id=8', 0, 'page', '', 0),
(9, 1, '2023-04-04 19:04:26', '2023-04-04 16:04:26', '', 'index', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2023-04-04 19:04:26', '2023-04-04 16:04:26', '', 8, 'http://akbaroff/?p=9', 0, 'revision', '', 0),
(11, 1, '2023-04-04 19:06:44', '2023-04-04 16:06:44', '', 'portfolio', '', 'publish', 'closed', 'closed', '', 'portfolio', '', '', '2023-04-04 19:06:44', '2023-04-04 16:06:44', '', 0, 'http://akbaroff/?page_id=11', 0, 'page', '', 0),
(12, 1, '2023-04-04 19:06:44', '2023-04-04 16:06:44', '', 'portfolio', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2023-04-04 19:06:44', '2023-04-04 16:06:44', '', 11, 'http://akbaroff/?p=12', 0, 'revision', '', 0),
(15, 1, '2023-04-04 19:17:37', '2023-04-04 16:17:37', '', 'article', '', 'publish', 'closed', 'closed', '', 'article', '', '', '2023-04-04 19:17:37', '2023-04-04 16:17:37', '', 0, 'http://akbaroff/?page_id=15', 0, 'page', '', 0),
(16, 1, '2023-04-04 19:17:37', '2023-04-04 16:17:37', '', 'article', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2023-04-04 19:17:37', '2023-04-04 16:17:37', '', 15, 'http://akbaroff/?p=16', 0, 'revision', '', 0),
(20, 1, '2023-04-04 19:28:09', '2023-04-04 16:28:09', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'portfolioPost', 'portfoliopost', 'publish', 'closed', 'closed', '', 'group_642c4f59c93ac', '', '', '2023-04-04 23:04:14', '2023-04-04 20:04:14', '', 0, 'http://akbaroff/?post_type=acf-field-group&#038;p=20', 0, 'acf-field-group', '', 0),
(21, 1, '2023-04-04 19:28:09', '2023-04-04 16:28:09', 'a:16:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:12:"preview_size";s:6:"medium";}', 'first_img', 'firstimg', 'publish', 'closed', 'closed', '', 'field_642c4f5aced3e', '', '', '2023-04-04 19:28:09', '2023-04-04 16:28:09', '', 20, 'http://akbaroff/?post_type=acf-field&p=21', 0, 'acf-field', '', 0),
(22, 1, '2023-04-04 19:28:09', '2023-04-04 16:28:09', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'title', 'title', 'publish', 'closed', 'closed', '', 'field_642c4f91ced3f', '', '', '2023-04-04 19:28:09', '2023-04-04 16:28:09', '', 20, 'http://akbaroff/?post_type=acf-field&p=22', 1, 'acf-field', '', 0),
(23, 1, '2023-04-04 19:28:09', '2023-04-04 16:28:09', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'subtitle', 'subtitle', 'publish', 'closed', 'closed', '', 'field_642c4fd6ced40', '', '', '2023-04-04 19:28:09', '2023-04-04 16:28:09', '', 20, 'http://akbaroff/?post_type=acf-field&p=23', 2, 'acf-field', '', 0),
(25, 1, '2023-04-04 19:29:58', '2023-04-04 16:29:58', '', 'test', '', 'publish', 'closed', 'closed', '', 'test', '', '', '2023-04-04 19:30:00', '2023-04-04 16:30:00', '', 0, 'http://akbaroff/?post_type=postp&#038;p=25', 0, 'postp', '', 0),
(26, 1, '2023-04-04 19:29:19', '2023-04-04 16:29:19', '', 'klassik1', '', 'inherit', 'open', 'closed', '', 'klassik1', '', '', '2023-04-05 00:40:46', '2023-04-04 21:40:46', '', 25, 'http://akbaroff/wp-content/uploads/2023/04/klassik1.jpg', 0, 'attachment', 'image/jpeg', 0),
(27, 1, '2023-04-04 19:37:35', '2023-04-04 16:37:35', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-2', '', '', '2023-04-04 19:37:37', '2023-04-04 16:37:37', '', 0, 'http://akbaroff/?post_type=postp&#038;p=27', 0, 'postp', '', 0),
(30, 1, '2023-04-04 20:55:11', '2023-04-04 17:55:11', '', 'test', '', 'publish', 'open', 'open', '', 'test', '', '', '2023-04-05 00:39:55', '2023-04-04 21:39:55', '', 0, 'http://akbaroff/?p=30', 0, 'post', '', 0),
(31, 1, '2023-04-04 20:55:11', '2023-04-04 17:55:11', '', 'test', '', 'inherit', 'closed', 'closed', '', '30-revision-v1', '', '', '2023-04-04 20:55:11', '2023-04-04 17:55:11', '', 30, 'http://akbaroff/?p=31', 0, 'revision', '', 0),
(32, 1, '2023-04-04 20:55:14', '2023-04-04 17:55:14', '', 'test', '', 'inherit', 'closed', 'closed', '', '30-revision-v1', '', '', '2023-04-04 20:55:14', '2023-04-04 17:55:14', '', 30, 'http://akbaroff/?p=32', 0, 'revision', '', 0),
(33, 1, '2023-04-04 21:19:43', '2023-04-04 18:19:43', '', 'test2', '', 'publish', 'open', 'open', '', 'test2', '', '', '2023-04-05 00:40:54', '2023-04-04 21:40:54', '', 0, 'http://akbaroff/?p=33', 0, 'post', '', 0),
(34, 1, '2023-04-04 21:19:43', '2023-04-04 18:19:43', '', 'test2', '', 'inherit', 'closed', 'closed', '', '33-revision-v1', '', '', '2023-04-04 21:19:43', '2023-04-04 18:19:43', '', 33, 'http://akbaroff/?p=34', 0, 'revision', '', 0),
(35, 1, '2023-04-04 21:19:47', '2023-04-04 18:19:47', '', 'test2', '', 'inherit', 'closed', 'closed', '', '33-revision-v1', '', '', '2023-04-04 21:19:47', '2023-04-04 18:19:47', '', 33, 'http://akbaroff/?p=35', 0, 'revision', '', 0),
(39, 1, '2023-04-04 22:11:06', '2023-04-04 19:11:06', 'a:19:{s:10:"aria-label";s:0:"";s:4:"type";s:7:"gallery";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:7:"library";s:3:"all";s:3:"min";s:0:"";s:3:"max";s:0:"";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:6:"insert";s:6:"append";s:12:"preview_size";s:6:"medium";}', 'galarey', 'galarey', 'publish', 'closed', 'closed', '', 'field_642c762b37427', '', '', '2023-04-04 23:04:14', '2023-04-04 20:04:14', '', 20, 'http://akbaroff/?post_type=acf-field&#038;p=39', 3, 'acf-field', '', 0),
(41, 1, '2023-04-04 22:15:44', '2023-04-04 19:15:44', '', 'test3', '', 'publish', 'open', 'open', '', 'test3', '', '', '2023-04-04 23:01:39', '2023-04-04 20:01:39', '', 0, 'http://akbaroff/?p=41', 0, 'post', '', 0),
(42, 1, '2023-04-04 22:14:41', '2023-04-04 19:14:41', '', 'loft1', '', 'inherit', 'open', 'closed', '', 'loft1', '', '', '2023-04-04 22:14:41', '2023-04-04 19:14:41', '', 41, 'http://akbaroff/wp-content/uploads/2023/04/loft1.jpg', 0, 'attachment', 'image/jpeg', 0),
(43, 1, '2023-04-04 22:14:43', '2023-04-04 19:14:43', '', 'minimalizm1', '', 'inherit', 'open', 'closed', '', 'minimalizm1', '', '', '2023-04-04 22:14:43', '2023-04-04 19:14:43', '', 41, 'http://akbaroff/wp-content/uploads/2023/04/minimalizm1.jpg', 0, 'attachment', 'image/jpeg', 0),
(44, 1, '2023-04-04 22:14:46', '2023-04-04 19:14:46', '', 'modern1', '', 'inherit', 'open', 'closed', '', 'modern1', '', '', '2023-04-04 22:14:46', '2023-04-04 19:14:46', '', 41, 'http://akbaroff/wp-content/uploads/2023/04/modern1.jpg', 0, 'attachment', 'image/jpeg', 0),
(45, 1, '2023-04-04 22:14:48', '2023-04-04 19:14:48', '', 'more', '', 'inherit', 'open', 'closed', '', 'more', '', '', '2023-04-04 22:14:48', '2023-04-04 19:14:48', '', 41, 'http://akbaroff/wp-content/uploads/2023/04/more.jpg', 0, 'attachment', 'image/jpeg', 0),
(46, 1, '2023-04-04 22:14:50', '2023-04-04 19:14:50', '', 'neo1', '', 'inherit', 'open', 'closed', '', 'neo1', '', '', '2023-04-04 22:14:50', '2023-04-04 19:14:50', '', 41, 'http://akbaroff/wp-content/uploads/2023/04/neo1.jpg', 0, 'attachment', 'image/jpeg', 0),
(47, 1, '2023-04-04 22:15:44', '2023-04-04 19:15:44', '', 'test3', '', 'inherit', 'closed', 'closed', '', '41-revision-v1', '', '', '2023-04-04 22:15:44', '2023-04-04 19:15:44', '', 41, 'http://akbaroff/?p=47', 0, 'revision', '', 0),
(48, 1, '2023-04-04 22:15:47', '2023-04-04 19:15:47', '', 'test3', '', 'inherit', 'closed', 'closed', '', '41-revision-v1', '', '', '2023-04-04 22:15:47', '2023-04-04 19:15:47', '', 41, 'http://akbaroff/?p=48', 0, 'revision', '', 0),
(50, 1, '2023-04-04 23:01:39', '2023-04-04 20:01:39', '', 'test3', '', 'inherit', 'closed', 'closed', '', '41-revision-v1', '', '', '2023-04-04 23:01:39', '2023-04-04 20:01:39', '', 41, 'http://akbaroff/?p=50', 0, 'revision', '', 0),
(52, 1, '2023-04-05 00:39:40', '2023-04-04 21:39:40', '', 'test', '', 'inherit', 'closed', 'closed', '', '30-revision-v1', '', '', '2023-04-05 00:39:40', '2023-04-04 21:39:40', '', 30, 'http://akbaroff/?p=52', 0, 'revision', '', 0),
(53, 1, '2023-04-05 00:39:55', '2023-04-04 21:39:55', '', 'test', '', 'inherit', 'closed', 'closed', '', '30-revision-v1', '', '', '2023-04-05 00:39:55', '2023-04-04 21:39:55', '', 30, 'http://akbaroff/?p=53', 0, 'revision', '', 0),
(54, 1, '2023-04-05 00:40:54', '2023-04-04 21:40:54', '', 'test2', '', 'inherit', 'closed', 'closed', '', '33-revision-v1', '', '', '2023-04-05 00:40:54', '2023-04-04 21:40:54', '', 33, 'http://akbaroff/?p=54', 0, 'revision', '', 0),
(56, 1, '2023-04-05 11:36:02', '2023-04-05 08:36:02', '', 'logoO', '', 'inherit', 'open', 'closed', '', 'logoo', '', '', '2023-04-05 11:36:02', '2023-04-05 08:36:02', '', 0, 'http://akbaroff/wp-content/uploads/2023/04/logoO.png', 0, 'attachment', 'image/png', 0),
(57, 1, '2023-04-05 11:36:23', '2023-04-05 08:36:23', 'http://akbaroff/wp-content/uploads/2023/04/cropped-logoO.png', 'cropped-logoO.png', '', 'inherit', 'open', 'closed', '', 'cropped-logoo-png', '', '', '2023-04-05 11:36:23', '2023-04-05 08:36:23', '', 0, 'http://akbaroff/wp-content/uploads/2023/04/cropped-logoO.png', 0, 'attachment', 'image/png', 0),
(58, 1, '2023-05-06 11:52:20', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-05-06 11:52:20', '0000-00-00 00:00:00', '', 0, 'http://akbaroff/?p=58', 0, 'post', '', 0) ;

#
# Конец содержимого данных таблицы `wp_posts`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Структура таблицы `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(27, 2, 0),
(30, 2, 0),
(33, 2, 0),
(41, 2, 0) ;

#
# Конец содержимого данных таблицы `wp_term_relationships`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Структура таблицы `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'category', '', 0, 3),
(3, 3, 'port', '', 0, 0),
(4, 4, 'port', '', 0, 0) ;

#
# Конец содержимого данных таблицы `wp_term_taxonomy`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Структура таблицы `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_termmeta`
#
INSERT INTO `wp_termmeta` ( `meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 3, 'firstimg', '26'),
(2, 3, '_firstimg', 'field_642c4f5aced3e'),
(3, 3, 'title', 'teest'),
(4, 3, '_title', 'field_642c4f91ced3f'),
(5, 3, 'subtitle', 'testttttt'),
(6, 3, '_subtitle', 'field_642c4fd6ced40'),
(7, 4, 'firstimg', '26'),
(8, 4, '_firstimg', 'field_642c4f5aced3e'),
(9, 4, 'title', 'eqwe'),
(10, 4, '_title', 'field_642c4f91ced3f'),
(11, 4, 'subtitle', 'qwewqe'),
(12, 4, '_subtitle', 'field_642c4fd6ced40') ;

#
# Конец содержимого данных таблицы `wp_termmeta`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Структура таблицы `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Без рубрики', '%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8', 0),
(2, 'akbaroff', 'akbaroff', 0),
(3, 'test', 'test', 0),
(4, 'kjhk', 'm-m', 0) ;

#
# Конец содержимого данных таблицы `wp_terms`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Структура таблицы `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'akbaroffAdmin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:1:{s:64:"911fb598294e6b36049a4770a7d38efc39f43010d0930a0374d789b9ec1591a1";a:4:{s:10:"expiration";i:1683535937;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36";s:5:"login";i:1683363137;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '58'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}'),
(19, 1, 'wp_persisted_preferences', 'a:2:{s:14:"core/edit-post";a:3:{s:26:"isComplementaryAreaVisible";b:1;s:12:"welcomeGuide";b:0;s:10:"openPanels";a:4:{i:0;s:11:"post-status";i:1;s:19:"taxonomy-panel-port";i:2;s:15:"page-attributes";i:3;s:23:"taxonomy-panel-category";}}s:9:"_modified";s:24:"2023-04-04T20:01:05.627Z";}'),
(20, 1, 'manageedit-acf-taxonomycolumnshidden', 'a:1:{i:0;s:7:"acf-key";}'),
(21, 1, 'acf_user_settings', 'a:2:{s:20:"taxonomies-first-run";b:1;s:19:"post-type-first-run";b:1;}'),
(22, 1, 'closedpostboxes_acf-taxonomy', 'a:0:{}'),
(23, 1, 'metaboxhidden_acf-taxonomy', 'a:2:{i:0;s:21:"acf-advanced-settings";i:1;s:7:"slugdiv";}'),
(24, 1, 'manageedit-acf-post-typecolumnshidden', 'a:1:{i:0;s:7:"acf-key";}'),
(25, 1, 'closedpostboxes_acf-post-type', 'a:0:{}'),
(26, 1, 'metaboxhidden_acf-post-type', 'a:2:{i:0;s:21:"acf-advanced-settings";i:1;s:7:"slugdiv";}'),
(27, 1, 'wp_user-settings', 'libraryContent=browse&hidetb=1&editor=tinymce'),
(28, 1, 'wp_user-settings-time', '1680635745') ;

#
# Конец содержимого данных таблицы `wp_usermeta`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Структура таблицы `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'akbaroffAdmin', '$P$BYHBGIUQANOZ1Cy3vIWJE9wyxAi30Q0', 'akbaroffadmin', 'xibroxim11@gmail.com', 'http://akbaroff', '2023-04-04 06:25:27', '', 0, 'akbaroffAdmin') ;

#
# Конец содержимого данных таблицы `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

